//this is the 27 February 2012 rewrite

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "goto_tools.h"
#include "kd.h"

kd_tree::~kd_tree(){
  int i;
  delete [] mins;
  delete [] maxs;
  for(i=0;i<room;i++){
    delete [] tree[i];
    delete [] data[i];
  }
  delete [] tree;
  delete [] data;
  
}

kd_tree::kd_tree(int dd, int pp, double **mm, int *innin, double *nmin, \
double *nmax){
  
   int i,j,k,l,*inn,*use,*uinn,rct,lct,inp;
   double *tosort;
   
   tol=1.0e-7;
   
   room=pp;
   roomstep=10000;
   
   dim=dd;
   pts=pp;
   diagnostic=1;
   
   data=new double*[pts];
   for(i=0;i<pts;i++)data[i]=new double[dim];
   tree=new int*[pts];
   for(i=0;i<pts;i++){
     tree[i]=new int[4];
     //tree[i][0] will be the dimension being split
     //tree[i][1] will be left hand node (so, lt)
     //tree[i][2] will be right hand node (so, ge)
     //tree[i][3] will be parent
   }
   maxs=new double[dim];
   mins=new double[dim];
   
   for(i=0;i<dim;i++){
     mins[i]=nmin[i];
     maxs[i]=nmax[i];
   }
   
   for(i=0;i<pts;i++){
     for(j=0;j<dim;j++)data[i][j]=mm[i][j];
   }

   tosort=new double[pts];
   inn=new int[pts];

   for(i=0;i<pts;i++){
     tosort[i]=data[i][0];
     inn[i]=i;
   }
   
   sort(tosort,inn,pts);
   
   inp=pts/2;
   while(inp>0 && tosort[inp]-tosort[inp-1]<tol){
     //make sure that the division doesn't come in the middle of a bunch
     //of identical points
     inp--;
   }
   
   masterparent=inn[inp];
   //printf("inp %d masterparent %d\n",inp,masterparent);
   if(inp==0){
      rct=pts-1;
      lct=0; 
   }
   else{  
   rct=0;
   lct=0;
     for(j=0;j<pts;j++){
       if(masterparent!=j){
          if(data[j][0]<tosort[inp])lct++;
	  else rct++;
       }
     } 
   }//of masterparent!=0
   
   if(lct>0){
     use=new int[lct];
    
     
     for(j=0,i=0;i<pts;i++){
       if(i!=masterparent){
         if(data[i][0]<tosort[inp]){
	   use[j]=i;
	   j++;
	 }
       }
     }
     
     organize(use,masterparent,1,lct,1);
     
     delete [] use;
    
   }
   else tree[masterparent][1]=-1;
   
   if(rct>0){
     use=new int[rct];
     
     for(j=0,i=0;i<pts;i++){
       if(i!=masterparent){
         if(data[i][0]>=tosort[inp]){
	   use[j]=i;
	   j++;
	 } 
       }
     } 
     
     organize(use,masterparent,1,rct,2);
     
     delete [] use;
    
   }
   else tree[masterparent][2]=-1;
   
   tree[masterparent][3]=-1;
   tree[masterparent][0]=0;
   
   
   
   
  delete [] tosort;
  delete [] inn;

}

void kd_tree::organize(int *use, int parent, int idim, int ct, int dir){

    int i,j,k,l,*inn,newparent,ff,fb,inp;
    double *tosort,pivot,nn;
   
   if(idim>=dim)idim=0;
   
   /*printf("parent %d pdim %d dir %d\n",parent,idim-1,dir);
   for(i=0;i<ct;i++)printf("%d\n",use[i]);
   printf("\n");*/
   
  
   if(ct>2){
      inn=new int[ct];
      for(i=0;i<ct;i++)inn[i]=i;
      tosort=new double[ct];
      for(i=0;i<ct;i++)tosort[i]=data[use[i]][idim];
   
      sort(tosort,inn,ct);
   
      inp=ct/2;
      while(inp>0 && tosort[inp]-tosort[inp-1]<tol)inp--;
   
      newparent=use[inn[inp]];   
      pivot=data[newparent][idim];
   
      tree[parent][dir]=newparent;
      tree[newparent][3]=parent;
      tree[newparent][0]=idim;
      
      //now I need to re-order use[] so that I can pass it to another
      //call of ::organize and have the proper indices available
      
         k=use[inp];
	 use[inp]=newparent;
	 use[inn[inp]]=k;
	 
	 delete [] inn;
	 delete [] tosort;
      
      if(inp!=0){

	 ff=0;
	 fb=ct-1;
	 while(ff<inp && fb>inp){
	    if(data[use[ff]][idim]<pivot && \
	    data[use[fb]][idim]>=pivot){
	      ff++;
	      fb--;
	    }
	    else if(data[use[ff]][idim]>=pivot && \
	    data[use[fb]][idim]>=pivot){
	      fb--;
	    }
	    else if(data[use[ff]][idim]<pivot && \
	    data[use[fb]][idim]<pivot){
	      ff++;
	    }
	    else if(data[use[ff]][idim]>=pivot && \
	    data[use[fb]][idim]<pivot){
	      k=use[fb];
	      use[fb]=use[ff];
	      use[ff]=k;
	    }
	 }
	 
	 organize(use,newparent,idim+1,inp,1);
	 organize(&use[inp+1],newparent,idim+1,ct-inp-1,2);
	 
      
      }//if(inp!=0)
      else{
	
	tree[newparent][1]=-1;
	organize(&use[1],newparent,idim+1,ct-1,2);
	
      }//if(inp==0)
      
      
   }//if(ct>2)
   else if(ct==2){
     if(data[use[0]][idim]<data[use[1]][idim]){
       tree[parent][dir]=use[1];
       tree[use[1]][1]=use[0];
       tree[use[1]][2]=-1;
       tree[use[1]][3]=parent;
       tree[use[1]][0]=idim;
     }
     else{
       tree[parent][dir]=use[1];
       tree[use[1]][1]=-1;
       tree[use[1]][2]=use[0];
       tree[use[1]][3]=parent;
       tree[use[1]][0]=idim;
     }
     
     tree[use[0]][0]=idim+1;
     if(tree[use[0]][0]>=dim)tree[use[0]][0]=0;
     tree[use[0]][1]=-1;
     tree[use[0]][2]=-1;
     tree[use[0]][3]=use[1];
   
   }
   else if(ct==1){
      tree[parent][dir]=use[0];
      tree[use[0]][1]=-1;
      tree[use[0]][2]=-1;
      tree[use[0]][3]=parent;
      tree[use[0]][0]=idim;
   }
   else if(ct==0)printf("WARNING called organize with ct==0\n");
  
}

void kd_tree::write_tree(char *name){
   
   int i,j,k,l;
   FILE *output;

   output=fopen(name,"w");
   for(i=0;i<pts;i++){
     fprintf(output,"%d tree dim %d l %d r %d p %d ",\
     i,tree[i][0],tree[i][1],tree[i][2],tree[i][3]);
     fprintf(output,"    ");
     for(j=0;j<dim;j++)fprintf(output,"p%d %e ",j,data[i][j]);
     fprintf(output,"\n");
   
   
   }

   fclose(output);
}

void kd_tree::check_tree(int where){
   int i;
   

   
   if(where<0)where=masterparent;
   
      //printf("checking %d %d %d %d\n",where,tree[where][1],tree[where][2],tree[where][0]);
   
   if(tree[where][1]>-1)confirm(tree[where][0],where,1,tree[where][1]);
   
   //printf("confirmed 1\n");
   
   if(tree[where][2]>-1)confirm(tree[where][0],where,2,tree[where][2]);
   //printf("confirmed 2\n");
   
   if(tree[where][1]>-1)check_tree(tree[where][1]);
   if(tree[where][2]>-1)check_tree(tree[where][2]);
     
 
}

void kd_tree::confirm(int idim, int compareto, int dir, int where){
   
   //printf("confirm %d %d %d %d\n",idim,compareto,dir,where);
   
   if(dir==1){
     if(data[where][idim]>=data[compareto][idim])diagnostic=0;
     
     if(tree[where][1]>-1)confirm(idim,compareto,dir,tree[where][1]);
     if(tree[where][2]>-1)confirm(idim,compareto,dir,tree[where][2]);
     
   }
   else if(dir==2){
     if(data[where][idim]<data[compareto][idim])diagnostic=0;
     
     if(tree[where][1]>-1)confirm(idim,compareto,dir,tree[where][1]);
     if(tree[where][2]>-1)confirm(idim,compareto,dir,tree[where][2]);
   }
   
}

void kd_tree::add(double *v){
  
  int i,j,k,l,**tbuff,node,dir;
  double **dbuff;
  
  if(pts==room){
     dbuff=new double*[pts];
     for(i=0;i<pts;i++){
       dbuff[i]=new double[dim];
       for(j=0;j<dim;j++){
        dbuff[i][j]=data[i][j];
       }
       delete [] data[i];
     }
     delete [] data;
     
     tbuff=new int*[pts];
     for(i=0;i<pts;i++){
       tbuff[i]=new int[4];
       for(j=0;j<4;j++){
         tbuff[i][j]=tree[i][j];
       }
       delete [] tree[i];
     }
     delete [] tree;
     
     room+=roomstep;
     data=new double*[room];
     tree=new int*[room];
     for(i=0;i<room;i++){
       data[i]=new double[dim];
       tree[i]=new int[4];
     }
     
     for(i=0;i<pts;i++){
        for(j=0;j<dim;j++){
	  data[i][j]=dbuff[i][j];
	}
	delete [] dbuff[i];
	for(j=0;j<4;j++){
	  tree[i][j]=tbuff[i][j];
	}
	delete [] tbuff[i];
     }
     delete [] dbuff;
     delete [] tbuff;
     
  }//if(pts==room) and we have to make more room
  
  node=find_node(v);
  for(j=0;j<dim;j++)data[pts][j]=v[j];
  
  if(v[tree[node][0]]<data[node][tree[node][0]])dir=1;
  else dir=2;
  
  tree[node][dir]=pts;
  tree[pts][3]=node;
  tree[pts][0]=tree[node][0]+1;
  if(tree[pts][0]>=dim)tree[pts][0]=0;
  tree[pts][1]=-1;
  tree[pts][2]=-2;
  
  pts++;


}

int kd_tree::find_node(double *v){
   
    int i,j,k,l,nextstep,where;
    
    where=masterparent;
    
    if(v[tree[masterparent][0]]<data[masterparent][tree[masterparent][0]]){
      nextstep=tree[masterparent][1];
    }
    else nextstep=tree[masterparent][2];
    
    
    
    while(nextstep>-1){
      where=nextstep;   
      if(v[tree[where][0]]<data[where][tree[where][0]]){
        nextstep=tree[where][1];
      } 
      else nextstep=tree[where][2];
    }
    
    return where;
    
}

double kd_tree::distance(double *p1, double *p2){
  double dd;
  int i;
  
  dd=0.0;
  for(i=0;i<dim;i++)dd+=power((p1[i]-p2[i])/(maxs[i]-mins[i]),2);
  dd=sqrt(dd);
  return dd;
}

void kd_tree::neigh_check(double *v, int kk, int *neigh, double *dd,\
 int where, int wherefrom){

   int i,j,k,l,side;
   double dtry,dwhere;
   
   if(v[tree[where][0]]<data[where][tree[where][0]])side=1;
   else side=2;
   
   dtry=fabs((v[tree[where][0]]-data[where][tree[where][0]])/\
   (maxs[tree[where][0]]-mins[tree[where][0]]));
   
   if(dtry<=dd[kk-1]){
   
     dwhere=distance(data[where],v);
     if(dwhere<dd[kk-1]){
        for(i=kk-2;i>=0 && dd[i]>dwhere;i--){
           dd[i+1]=dd[i];
	   neigh[i+1]=neigh[i];
	}
	i++;
	
	
	dd[i]=dwhere;
	neigh[i]=where;
     }
     
     if(wherefrom==tree[where][3] || wherefrom==tree[where][side]){
      if(tree[where][3-side]>-1){
       neigh_check(v,kk,neigh,dd,tree[where][3-side],where);
       //check the other side of this node
      }
     }
     
   }
   
   if(wherefrom==tree[where][3]){
     if(tree[where][side]>-1){
       neigh_check(v,kk,neigh,dd,tree[where][side],where);
       //check the side of this node I am naturally on
     } 
   }
   else{
     if(tree[where][3]>-1){
       neigh_check(v,kk,neigh,dd,tree[where][3],where);
       //check the parent of this node, if that is not where I came from
     }
   }
    

}

void kd_tree::nn_srch(double *v, int kk, int *neigh, double *dd){

   int i,j,k,l,node,where,behind,*inn;
   double ddnode,ddtry;
  
   node=find_node(v);
   ddnode=distance(v,data[node]);
   dd[0]=ddnode;
   neigh[0]=node;
   
  // printf("node is %d dd %e\n",node,ddnode);
   
   for(i=1;i<kk;i++){
     dd[i]=dd[0]+double(i)*1.0e6;
     neigh[i]=-1;
   }
   
   /*j=1;
   for(i=0;j<kk;i++){
     
     l=1;
     for(k=0;k<j;k++){
       if(neigh[k]==i)l=0;
     }
     if(l==1){
       dd[j]=distance(data[i],v);
       neigh[j]=i;
       j++;
     }
     
   }*/
   
   
  // sort(dd,neigh,kk);
   
   
   
   neigh_check(v,kk,neigh,dd,tree[node][3],node);
  
}


