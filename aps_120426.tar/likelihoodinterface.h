#include "goto_tools.h"
#include "kd.h"
#define likeletters 500

//the two external function definitions below are only needed to
//interface with CAMB and the WMAP 7 likelihood function
//as provided in aps_cmb_module.cpp


extern "C" void \
camb_wrap_(double*,double*,double*,double*,double*,double*);
extern "C" void wmaplikeness_(double*,double*,double*,double*,double*);


class likelihood{
 private:
  
  double *fpredicted,*ddmin,*ddmax,*ddavg,*chisq,*sigma;
     //f is the distance from the confidence ball center
     //fpredicted is what Kriging predicted for f
     //sigma is the variance Kriging predicted for f
     
     

   
  //CAMB and WMAP necessary arrays

  int room,roomstep,nprinted;
  
 
  
  double *ldata,*lx;
  int lpts;
    
  double *mins,*maxs,rkp,*suboptpct,*kpa;
    //limits on the cosmologicalparameters
    
  int nok,nbad,datapts,startpts; 
     //npts is number of sample points accumulated 
     //nparams is the number of theoretical parameters
     
  int nparams;
  
  Ran *dice;
  kd_tree **kptr;
  
 
 public:
  char **pnames,masteroutname[100];
   //cmd will be a command that calls an external program (the likelihood
   //code) which takes a point in parameter space and outputs a curve
   //to be compared to the data
   
   //pstore will contain the parameter values to be input to the
   //likelihood code
   
   //dname is the name of the file that will contain the
   //data produced by the likelihood code
   
   double junk,kriging_parameter,maxerr;
   double *ans1,*ans2,db,kpmin,chimin;
     
   int npts,nsamples,threads,ngood,suboptimal,suboptct,*suboptime;
   int krigct,addct,lingerswitch,lingermax,kk,spentlingering;
   double krigtimewall,addtimewall,*CLmin,*CLmax;
   double krigtimecpu,addtimecpu;
   double target,precision;
   int lastsubop,writevery;
   
   
  
   
   likelihood();
   likelihood(int,double*,double*);
   ~likelihood();
   void initialize(double**,int);
   void resume(char*);
   
   double call_likelihood(double*);
   void add_pt(double*,double*,double,double,double);
     //now you feed true chi and f to add_pt
     //so that the convergence files can keep track of diffpct
     //on kriging
   double covariogram(double*,double*,int);
   void predict(double**,double*,double*,double*,int,int,double*,double*,int);
   void sample_pts(int);
   void write_pts();
   void set_kp(int);
   double test_kp(int,char*);
   

   

};
